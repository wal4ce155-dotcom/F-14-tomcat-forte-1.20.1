package com.example.f14tomcat.item;

import com.example.f14tomcat.entity.F14Entity;
import com.example.f14tomcat.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class F14Item extends Item {
    public F14Item(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();

        if (!level.isClientSide) {
            BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
            F14Entity plane = ModEntities.F14.get().create(level);
            if (plane == null) {
                return InteractionResult.FAIL;
            }
            plane.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, context.getRotation(), 0.0F);
            if (!level.noCollision(plane, plane.getBoundingBox())) {
                return InteractionResult.FAIL;
            }
            level.addFreshEntity(plane);
            if (player == null || !player.getAbilities().instabuild) {
                context.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}

package com.example.f14tomcat.registry;

import com.example.f14tomcat.F14Mod;
import com.example.f14tomcat.item.F14Item;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, F14Mod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, F14Mod.MODID);

    public static final RegistryObject<Item> F14 = ITEMS.register("f14_tomcat",
            () -> new F14Item(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.f14tomcat"))
                    .icon(() -> new ItemStack(F14.get()))
                    .displayItems((params, output) -> output.accept(F14.get()))
                    .build());

    private ModItems() {}
}

package com.example.f14tomcat.client;

import com.example.f14tomcat.F14Mod;
import com.example.f14tomcat.entity.F14Entity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class F14Renderer extends EntityRenderer<F14Entity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(F14Mod.MODID, "textures/entity/f14_tomcat.png");

    private final F14Model model;

    public F14Renderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 1.6F;
        this.model = new F14Model(context.bakeLayer(F14Model.LAYER));
    }

    @Override
    public void render(F14Entity entity, float yaw, float partialTicks, PoseStack poseStack,
                       MultiBufferSource buffers, int light) {
        poseStack.pushPose();

        float pitch = Mth.lerp(partialTicks, entity.xRotO, entity.getXRot());
        float roll = Mth.lerp(partialTicks, entity.rollO, entity.roll);

        poseStack.translate(0.0D, F14Entity.PIVOT_Y, 0.0D);
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - yaw));
        poseStack.mulPose(Axis.XP.rotationDegrees(-pitch));
        poseStack.mulPose(Axis.ZP.rotationDegrees(-roll));
        poseStack.scale(-1.0F, -1.0F, 1.0F);

        // Em primeira pessoa dentro do avião, esconde a cabine para não bloquear a visão
        Minecraft mc = Minecraft.getInstance();
        boolean hideCanopy = mc.player != null
                && mc.options.getCameraType().isFirstPerson()
                && entity.hasPassenger(mc.player);
        this.model.canopy.visible = !hideCanopy;

        this.model.setupAnim(entity, 0.0F, 0.0F, entity.tickCount + partialTicks, 0.0F, 0.0F);
        VertexConsumer consumer = buffers.getBuffer(this.model.renderType(TEXTURE));
        this.model.renderToBuffer(poseStack, consumer, light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);

        poseStack.popPose();
        super.render(entity, yaw, partialTicks, poseStack, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(F14Entity entity) {
        return TEXTURE;
    }
}

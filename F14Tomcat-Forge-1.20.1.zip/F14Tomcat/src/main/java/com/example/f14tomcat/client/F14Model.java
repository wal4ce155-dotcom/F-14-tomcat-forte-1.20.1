package com.example.f14tomcat.client;

import com.example.f14tomcat.F14Mod;
import com.example.f14tomcat.entity.F14Entity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Modelo simplificado do F-14 feito só com cubos. Unidades em pixels (16 = 1 bloco).
 * Origem = centro do avião, nariz aponta para -Z, y negativo = para cima.
 * Textura 256x256: linhas 0-127 cinza (casco), 128-191 escuro (canopy/bocais), 192-255 laranja (chama).
 */
public class F14Model extends EntityModel<F14Entity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(F14Mod.MODID, "f14_tomcat"), "main");

    private final ModelPart root;
    public final ModelPart canopy;
    private final ModelPart flames;

    public F14Model(ModelPart root) {
        this.root = root;
        this.canopy = root.getChild("canopy");
        this.flames = root.getChild("flames");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("hull", CubeListBuilder.create().texOffs(0, 0)
                        .addBox(-10, -8, -40, 20, 12, 80)      // fuselagem
                        .addBox(-6, -6, -64, 12, 8, 24)        // nariz
                        .addBox(-3, -4, -72, 6, 5, 8)          // radome
                        .addBox(-17, -2, -30, 7, 8, 36)        // entrada de ar esquerda
                        .addBox(10, -2, -30, 7, 8, 36)         // entrada de ar direita
                        .addBox(-13, -4, 20, 10, 9, 36)        // nacele esquerda
                        .addBox(3, -4, 20, 10, 9, 36)          // nacele direita
                        .addBox(-10, -26, 38, 2, 24, 16)       // deriva esquerda
                        .addBox(8, -26, 38, 2, 24, 16),        // deriva direita
                PartPose.ZERO);

        root.addOrReplaceChild("dark", CubeListBuilder.create().texOffs(0, 128)
                        .addBox(-12, -3, 56, 8, 7, 4)          // bocal esquerdo
                        .addBox(4, -3, 56, 8, 7, 4)            // bocal direito
                        .addBox(-16, -1, -31, 5, 6, 1)         // boca da entrada esquerda
                        .addBox(11, -1, -31, 5, 6, 1),         // boca da entrada direita
                PartPose.ZERO);

        root.addOrReplaceChild("canopy", CubeListBuilder.create().texOffs(0, 128)
                        .addBox(-5, -18, -44, 10, 10, 38),
                PartPose.ZERO);

        // Asas (varridas para trás)
        root.addOrReplaceChild("wing_l", CubeListBuilder.create().texOffs(0, 0)
                        .addBox(-24, -1, -12, 24, 2, 30)
                        .addBox(-44, -1, -4, 20, 2, 16),
                PartPose.offsetAndRotation(-9, 0, -6, 0.0F, 0.5F, 0.0F));
        root.addOrReplaceChild("wing_r", CubeListBuilder.create().texOffs(0, 0)
                        .addBox(0, -1, -12, 24, 2, 30)
                        .addBox(24, -1, -4, 20, 2, 16),
                PartPose.offsetAndRotation(9, 0, -6, 0.0F, -0.5F, 0.0F));

        // Estabilizadores horizontais
        root.addOrReplaceChild("tail_l", CubeListBuilder.create().texOffs(0, 0)
                        .addBox(-24, -1, -4, 24, 2, 16),
                PartPose.offsetAndRotation(-9, 1, 48, 0.0F, 0.4F, 0.0F));
        root.addOrReplaceChild("tail_r", CubeListBuilder.create().texOffs(0, 0)
                        .addBox(0, -1, -4, 24, 2, 16),
                PartPose.offsetAndRotation(9, 1, 48, 0.0F, -0.4F, 0.0F));

        // Chama do pós-combustor
        root.addOrReplaceChild("flames", CubeListBuilder.create().texOffs(0, 192)
                        .addBox(-11, -1, 60, 6, 5, 14)
                        .addBox(5, -1, 60, 6, 5, 14),
                PartPose.ZERO);

        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(F14Entity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        this.flames.visible = entity.isAfterburnerVisible();
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int light, int overlay,
                               float r, float g, float b, float a) {
        this.root.render(poseStack, buffer, light, overlay, r, g, b, a);
    }
}

package com.example.f14tomcat.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.entity.player.Player;

/** Código que só existe no cliente. Só é chamado quando level.isClientSide == true. */
public final class ClientHelper {
    private ClientHelper() {}

    public static boolean isBoostPressed() {
        return Minecraft.getInstance().options.keyJump.isDown();
    }

    public static void showHud(Player player, float speed, double y, boolean boost, float throttle) {
        int kmh = Math.round(speed * 72.0F);
        MutableComponent text = Component.translatable("hud.f14tomcat.status",
                kmh, Math.round(y), Math.round(throttle * 100.0F));
        if (boost) {
            text.append(Component.literal("  ")).append(Component.translatable("hud.f14tomcat.afterburner"));
        }
        player.displayClientMessage(text, true);
    }
}

package com.example.f14tomcat.registry;

import com.example.f14tomcat.F14Mod;
import com.example.f14tomcat.entity.F14Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, F14Mod.MODID);

    public static final RegistryObject<EntityType<F14Entity>> F14 = ENTITIES.register("f14_tomcat",
            () -> EntityType.Builder.<F14Entity>of(F14Entity::new, MobCategory.MISC)
                    .sized(4.0F, 1.8F)
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(F14Mod.MODID, "f14_tomcat").toString()));

    private ModEntities() {}
}

package com.example.f14tomcat.entity;

import com.example.f14tomcat.client.ClientHelper;
import com.example.f14tomcat.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/**
 * F-14 Tomcat: 2 lugares. O piloto (primeiro passageiro) controla:
 *  - Olhar (mouse / arrastar na tela): direção do avião
 *  - W / S: aumenta / diminui a aceleração
 *  - Pular (espaço): pós-combustor
 *  - Agachar (shift): sair
 * A simulação roda no cliente do piloto (como o barco/cavalo) e o servidor aceita a posição.
 */
public class F14Entity extends Entity {
    /** Altura (em blocos) do centro do modelo em relação aos "pés" da entidade. */
    public static final double PIVOT_Y = 0.5D;

    public static final float STALL_SPEED = 0.55F;   // blocos/tick  (~40 km/h)
    public static final float MAX_SPEED = 2.0F;      // blocos/tick  (~144 km/h)
    public static final float BOOST_SPEED = 3.2F;    // blocos/tick  (~230 km/h)

    private static final float D2R = (float) Math.PI / 180.0F;

    private float speed;
    private float throttle;
    private float damage;
    private float visualSpeed;

    public float roll;
    public float rollO;

    public F14Entity(EntityType<? extends F14Entity> type, Level level) {
        super(type, level);
    }

    /** Vetor de direção para pitch/yaw (graus) no padrão do Minecraft. */
    public static Vec3 lookVector(float pitch, float yaw) {
        float p = pitch * D2R;
        float y = -yaw * D2R;
        float cy = Mth.cos(y);
        float sy = Mth.sin(y);
        float cp = Mth.cos(p);
        float sp = Mth.sin(p);
        return new Vec3(sy * cp, -sp, cy * cp);
    }

    public boolean isAfterburnerVisible() {
        return this.visualSpeed > MAX_SPEED + 0.15F;
    }

    // ---------------------------------------------------------------- tick

    @Override
    public void tick() {
        super.tick();
        this.rollO = this.roll;
        this.fallDistance = 0.0F;

        LivingEntity pilot = this.getControllingPassenger();

        if (this.level().isClientSide) {
            this.updateClientVisuals();
        }

        if (pilot instanceof Player player && this.isControlledByLocalInstance()) {
            this.flyAsPilot(player);
        } else if (pilot == null) {
            this.speed = 0.0F;
            this.throttle = 0.0F;
            if (!this.level().isClientSide) {
                this.drift();
            }
        }

        for (Entity passenger : this.getPassengers()) {
            passenger.fallDistance = 0.0F;
        }
    }

    private void updateClientVisuals() {
        double dx = this.getX() - this.xOld;
        double dy = this.getY() - this.yOld;
        double dz = this.getZ() - this.zOld;
        float moved = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        this.visualSpeed += (moved - this.visualSpeed) * 0.25F;

        float yawRate = Mth.wrapDegrees(this.getYRot() - this.yRotO);
        float targetRoll = this.onGround ? 0.0F : Mth.clamp(yawRate * 12.0F, -60.0F, 60.0F);
        this.roll += (targetRoll - this.roll) * 0.15F;
    }

    /** Sem piloto: cai com a gravidade e nivela o nariz. */
    private void drift() {
        this.setXRot(this.getXRot() * 0.9F);
        double vy = Math.max(this.getDeltaMovement().y - 0.04D, -1.0D);
        this.setDeltaMovement(0.0D, vy, 0.0D);
        this.move(MoverType.SELF, this.getDeltaMovement());
        if (this.onGround) {
            this.setDeltaMovement(Vec3.ZERO);
        }
    }

    private void flyAsPilot(Player pilot) {
        boolean boost = ClientHelper.isBoostPressed();

        // Aceleração
        this.throttle = Mth.clamp(this.throttle + pilot.zza * 0.02F, 0.0F, 1.0F);
        float target = boost ? BOOST_SPEED : this.throttle * MAX_SPEED;
        if (target > this.speed) {
            this.speed += Math.min(target - this.speed, boost ? 0.03F : 0.012F);
        } else {
            this.speed += (target - this.speed) * 0.02F;
        }

        boolean canFly = this.speed >= STALL_SPEED;
        boolean nearGround = this.onGround
                || !this.level().noCollision(this, this.getBoundingBox().move(0.0D, -0.25D, 0.0D));

        if (nearGround && target < this.speed) {
            this.speed *= 0.97F; // freio de roda
        }

        // Direção desejada = para onde o piloto olha
        float targetYaw = pilot.getYRot();
        float targetPitch = Mth.clamp(pilot.getXRot(), -75.0F, 75.0F);
        if (!canFly) {
            // devagar demais: no chão taxia nivelado, no ar entra em stall (nariz cai)
            targetPitch = nearGround ? 0.0F : Math.max(targetPitch, 40.0F);
        } else if (nearGround) {
            // perto do chão não deixa enterrar o nariz (arredondamento no pouso)
            targetPitch = Math.min(targetPitch, 0.0F);
        }

        float maxTurn = 1.0F + 3.0F * Mth.clamp(this.speed / 1.5F, 0.0F, 1.0F);
        float yawDiff = Mth.wrapDegrees(targetYaw - this.getYRot());
        this.setYRot(this.getYRot() + Mth.clamp(yawDiff, -maxTurn, maxTurn));
        this.setXRot(this.getXRot() + Mth.clamp(targetPitch - this.getXRot(), -3.0F, 3.0F));

        // Mergulho ganha velocidade, subida perde
        Vec3 dir = lookVector(this.getXRot(), this.getYRot());
        this.speed += (float) -dir.y * 0.02F;
        this.speed = Mth.clamp(this.speed, 0.0F, BOOST_SPEED + 0.6F);

        Vec3 motion = dir.scale(this.speed);
        if (!canFly) {
            motion = motion.add(0.0D, -0.1D, 0.0D);
        }
        this.setDeltaMovement(motion);
        this.move(MoverType.SELF, motion);

        if (this.horizontalCollision) {
            this.speed *= 0.5F;
        }

        if (this.tickCount % 4 == 0) {
            ClientHelper.showHud(pilot, this.speed, this.getY(), this.speed > MAX_SPEED + 0.15F, this.throttle);
        }
    }

    // ---------------------------------------------------------------- passageiros

    @Override
    public LivingEntity getControllingPassenger() {
        return this.getFirstPassenger() instanceof LivingEntity living ? living : null;
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return this.getPassengers().size() < 2;
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!this.hasPassenger(passenger)) {
            return;
        }
        int seat = this.getPassengers().indexOf(passenger);
        double forward = seat == 0 ? 1.9D : 0.8D;
        Vec3 dir = lookVector(this.getXRot(), this.getYRot());
        callback.accept(passenger,
                this.getX() + dir.x * forward,
                this.getY() + PIVOT_Y - 0.57D + dir.y * forward,
                this.getZ() + dir.z * forward);
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (player.isSecondaryUseActive()) {
            return InteractionResult.PASS;
        }
        if (!this.level().isClientSide) {
            return player.startRiding(this) ? InteractionResult.CONSUME : InteractionResult.PASS;
        }
        return InteractionResult.SUCCESS;
    }

    // ---------------------------------------------------------------- dano / misc

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isInvulnerableTo(source)) {
            return false;
        }
        if (!this.level().isClientSide && !this.isRemoved()) {
            this.damage += amount;
            boolean creative = source.getEntity() instanceof Player p && p.getAbilities().instabuild;
            if (creative || this.damage > 40.0F) {
                if (!creative && this.level().getGameRules().getBoolean(GameRules.RULE_DOENTITYDROPS)) {
                    this.spawnAtLocation(ModItems.F14.get());
                }
                this.discard();
            }
        }
        return true;
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean isPickable() {
        return !this.isRemoved();
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ModItems.F14.get());
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return this.getBoundingBox().inflate(3.0D);
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}

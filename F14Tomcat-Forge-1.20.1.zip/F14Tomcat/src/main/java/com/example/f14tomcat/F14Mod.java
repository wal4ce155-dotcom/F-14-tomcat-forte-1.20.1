package com.example.f14tomcat;

import com.example.f14tomcat.registry.ModEntities;
import com.example.f14tomcat.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(F14Mod.MODID)
public class F14Mod {
    public static final String MODID = "f14tomcat";

    public F14Mod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
    }
}

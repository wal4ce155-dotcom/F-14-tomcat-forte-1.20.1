# F-14 Tomcat — Forge 1.20.1

Caça F-14 pilotável (2 lugares) para Minecraft Forge 1.20.1 (Zalith Launcher / PC).

## Como obter o .jar (sem PC)
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta.
2. Aba **Actions** → "Build mod" → espere terminar.
3. Baixe o artefato **f14tomcat-jar** (dentro vem o `f14tomcat-1.0.0.jar`).

No PC: instale JDK 17 + Gradle 8.1.1 e rode `gradle build`. O jar sai em `build/libs/`.

## Instalar no Zalith Launcher
1. Instale o **Forge 1.20.1** (Zalith → criar versão → Forge → 1.20.1).
2. Coloque o `f14tomcat-1.0.0.jar` na pasta `mods` dessa versão.
3. Abra o jogo. O avião está na aba criativa **F-14 Tomcat** ou: `/give @p f14tomcat:f14_tomcat`

## Controles
- Clique direito no avião: entrar (1º = piloto, 2º = RIO)
- **Olhar** (arrastar a tela): o avião vira para onde você olha
- **W / S**: aumentar / diminuir aceleração
- **Pular**: pós-combustor
- **Agachar**: sair
- Decolagem: passe de ~40 km/h e olhe para cima. Abaixo disso o avião entra em stall.
- Bater no avião com a mão destrói e devolve o item.

## Servidor dedicado
Coloque `allow-flight=true` no `server.properties`.

## Ajustes
Velocidades e curvas estão em `entity/F14Entity.java` (MAX_SPEED, BOOST_SPEED, STALL_SPEED).
O modelo é feito de cubos em `client/F14Model.java`; dá para trocar por um modelo do Blockbench.
